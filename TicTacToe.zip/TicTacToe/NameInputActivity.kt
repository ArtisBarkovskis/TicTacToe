class NameInputActivity {
}