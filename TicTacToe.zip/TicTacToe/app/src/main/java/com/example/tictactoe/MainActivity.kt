package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var buttons: Array<Button>
    private lateinit var playerTurnText: TextView
    private val board = Array(3) { arrayOfNulls<Player?>(3) }
    private var currentPlayer = Player.Player1
    private var gameOver = false
    private var gameTie = false
    private var numPlayers = 1
    private var player1name: String? = null
    private var player2name: String? = null

    enum class Player { Player1, Player2 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // iegust speletaju skaitu un vardus
        numPlayers = intent.getIntExtra("numPlayers", 1)
        player1name = intent.getStringExtra("player1Name")
        if (numPlayers == 1) {
            player2name = "Computer"
        } else {
            player2name = intent.getStringExtra("player2Name")
        }
        updatePlayerTurnText()
        // izveido masivu no 9 pogam
        buttons = arrayOf<Button>(
            findViewById(R.id.button1),
            findViewById(R.id.button2),
            findViewById(R.id.button3),
            findViewById(R.id.button4),
            findViewById(R.id.button5),
            findViewById(R.id.button6),
            findViewById(R.id.button7),
            findViewById(R.id.button8),
            findViewById(R.id.button9)
        )
        for (i in 0..2) {
            for (j in 0..2) {
                buttons[i * 3 + j].setOnClickListener {
                    buttonClick(buttons[i * 3 + j], i, j)
                }
            }
        }
        // play again un main menu pogas
        val playAgainButton = findViewById<Button>(R.id.play_again_button)
        playAgainButton.setOnClickListener {
            resetBoard()
        }
        val mainMenuButton = findViewById<Button>(R.id.main_menu_button)
        mainMenuButton.setOnClickListener {
            finish() // pabeidz aktivitati, un atgriezas uz sakuma aktivitati
        }
    }
    // izpilda AI gajienu
    private fun moveAI() {
        // parbauda vai spele nav beigusies
        if (gameOver) {
            return
        }
        // parbauda vai AI var uzvaret nakosaja gajiena
        for (i in 0 until 3) {
            for (j in 0 until 3) {
                if (board[i][j] == null) {
                    board[i][j] = Player.Player2
                    if (checkWinner(board, Player.Player2)) { //katram gajienam parbauda, vai tas uzvares speli
                        buttons[i * 3 + j].text = "O"
                        gameOver = true
                        updateWinnerText()
                        return
                    } else {
                        board[i][j] = null
                    }
                }
            }
        }
        // parbauda vai speletajs var uzvaret nakosaja gajiena, un nobloke to
        for (i in 0 until 3) {
            for (j in 0 until 3) {
                if (board[i][j] == null) {
                    board[i][j] = Player.Player1
                    if (checkWinner(board, Player.Player1)) {
                        buttons[i * 3 + j].text = "O"
                        board[i][j] = Player.Player2
                        if (checkGameOver()) {
                            gameOver = true
                            updateWinnerText()
                        } else {
                            currentPlayer = Player.Player1
                            updatePlayerTurnText()
                        }
                        return
                    } else {
                        board[i][j] = null
                    }
                }
            }
        }
        // ja nav uzvarosi gajieni, tad veic random gajienu
        val emptyCells = mutableListOf<Pair<Int, Int>>()
        for (i in 0 until 3) {
            for (j in 0 until 3) {
                if (board[i][j] == null) {
                    emptyCells.add(Pair(i, j))
                }
            }
        }
        if (emptyCells.isNotEmpty()) {  //parbauda vai ir iespejams gajiens
            val randomCell = emptyCells.random()
            board[randomCell.first][randomCell.second] = Player.Player2
            buttons[randomCell.first * 3 + randomCell.second].text = "O"
            if (checkGameOver()) {
                gameOver = true
                updateWinnerText()
            } else {
                currentPlayer = Player.Player1
                updatePlayerTurnText()
            }
        }
    }
    // funkcija, kas reseto visu no jauna
    private fun resetBoard() {
        for (i in 0..2) {
            for (j in 0..2) {
                board[i][j] = null
            }
        }
        for (button in buttons) {
            button.text = ""
        }
        currentPlayer = Player.Player1
        updatePlayerTurnText()
        gameOver = false
        gameTie = false
    }
    // funkcija kas apstrada pogas nospiesanu
    private fun buttonClick(button: Button, x: Int, y: Int) {
        // nelauj spiest pogu, ja spele ir beigusies, poga jau ir nospiesta, vai ja ir datora gajiens
        if (gameOver || board[x][y] != null || (currentPlayer == Player.Player2 && numPlayers == 1)) {
            return
        }
        // esosa speletaja iestatisana un laukuma aizrakstisana
        val player = if (currentPlayer == Player.Player1) {
            button.text = "X"
            Player.Player1
        } else {
            button.text = "O"
            Player.Player2
        }
        board[x][y] = player
        // parbauda vai spele beigusies, ja ne, tad maina gajienu uz nakamo speletaju
        if (checkGameOver()) {
            gameOver = true
            updateWinnerText()
        } else {
            currentPlayer = if (currentPlayer == Player.Player1) Player.Player2 else Player.Player1
            updatePlayerTurnText()
        }
        // Ja spele pret AI, tad izdara AI gajienu
        // Handler/looper atradu online ka der, lai AI pagaida 1sec pirms veic gajienu
        // sitas nefreezo visu aplikaciju, ka system timeout dara
        if (numPlayers == 1 && currentPlayer == Player.Player2) {
            Handler(Looper.getMainLooper()).postDelayed({
                moveAI()
            }, 1000)
        }
    }
    // gajiena vai uzvaretaja teksa updates
    private fun updatePlayerTurnText() {
        playerTurnText = findViewById(R.id.player_turn_text)
        if (currentPlayer == Player.Player1) {
            playerTurnText.text = "$player1name's turn"
        } else {
            playerTurnText.text = "$player2name's turn"
        }
    }
    private fun updateWinnerText() {
        playerTurnText = findViewById(R.id.player_turn_text)
        if (gameTie) {
            playerTurnText.text = "It's a Tie!"
        } else {
            if (currentPlayer == Player.Player1) {
                playerTurnText.text = "$player1name won!"
            } else {
                playerTurnText.text = "$player2name won!"
            }
        }
    }
    // papildus funkcija prieks AI, kas var parbaudit vai esosais speletajs nakosaja gajiena var uzvaret
    private fun checkWinner(board: Array<Array<Player?>>, player: Player): Boolean {
        // parbauda rindas
        for (i in 0..2) {
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player) {
                return true
            }
        }
        // parbauda kolonnas
        for (j in 0..2) {
            if (board[0][j] == player && board[1][j] == player && board[2][j] == player) {
                return true
            }
        }
        // parbauda diagonales
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player) {
            return true
        }
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player) {
            return true
        }
        return false
    }
    // parbauda vai spele ir uzvareta/neizskirta
    private fun checkGameOver(): Boolean {
        // parbauda rindas
        for (i in 0..2) {
            if (board[i][0] != null && board[i][0] == board[i][1] && board[i][0] == board[i][2]) {
                return true
            }
        }
        // parbauda kolonnas
        for (j in 0..2) {
            if (board[0][j] != null && board[0][j] == board[1][j] && board[0][j] == board[2][j]) {
                return true
            }
        }
        // parbauda diagonales
        if (board[0][0] != null && board[0][0] == board[1][1] && board[0][0] == board[2][2]) {
            return true
        }
        if (board[0][2] != null && board[0][2] == board[1][1] && board[0][2] == board[2][0]) {
            return true
        }
        // parbauda vai spele vel ir esosi gajieni
        for (i in 0..2) {
            for (j in 0..2) {
                if (board[i][j] == null) {
                    return false
                }
            }
        }
        // ja nav uzvarets, tad neizskirts
        gameTie = true
        return true
    }
}