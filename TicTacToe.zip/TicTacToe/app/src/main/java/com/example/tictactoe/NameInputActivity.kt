package com.example.tictactoe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

class NameInputActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_name_input)

        val numPlayers = intent.getIntExtra("numPlayers", 1)
        val player1EditText = findViewById<EditText>(R.id.player1_edit_text)
        val player2EditText = findViewById<EditText>(R.id.player2_edit_text)
        // paslepj 2. speletaju ja spele PvC
        if (numPlayers == 1) {
            player2EditText.visibility = View.GONE
        }
        // start game poga
        val startGameButton = findViewById<Button>(R.id.start_game_button)
        startGameButton.setOnClickListener {
            // ja neierakstija vardus, tad ieliek Player1 un Player2
            if (player1EditText.text.isEmpty()) {
                player1EditText.setText("Player1")
            }
            if (player2EditText.text.isEmpty()) {
                player2EditText.setText("Player2")
            }
            val nextIntent = Intent(this@NameInputActivity, MainActivity::class.java)
            nextIntent.putExtra("player1Name", player1EditText.text.toString())
            nextIntent.putExtra("player2Name", player2EditText.text.toString())
            nextIntent.putExtra("numPlayers", numPlayers)
            startActivity(nextIntent)
            finish()
        }
        // back poga
        val goBackButton = findViewById<Button>(R.id.go_back_button)
        goBackButton.setOnClickListener {
            finish()
        }
    }
}