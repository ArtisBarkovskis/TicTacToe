package com.example.tictactoe

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup

class MainMenuActivity : AppCompatActivity() {

    private lateinit var pvpButton: Button
    private lateinit var pvcButton: Button
    private lateinit var exitButton: Button
    private var shouldShowPopup = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)
        // popup-message, kaut kur online no vairakiem postiem apvienotas dalas, kas kaut ka strada :)
        if (shouldShowPopup) {
            // Inflate the custom popup message layout
            val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            val popupView = inflater.inflate(R.layout.popup_message, null)
            // Add the popup view to the activity's content view
            val container = findViewById<ViewGroup>(android.R.id.content)
            container.addView(popupView)
            // Set up the "Close" button click listener
            val closeButton = popupView.findViewById<Button>(R.id.close_button)
            closeButton.setOnClickListener {
                container.removeView(popupView)
            }
            // Set the flag to false so that the popup won't be shown again
            shouldShowPopup = false
        }
        // pvp, pvc un exit pogas
        pvpButton = findViewById(R.id.button_pvp)
        pvpButton.setOnClickListener {
            val intent = Intent(this, NameInputActivity::class.java)
            intent.putExtra("numPlayers", 2)
            startActivity(intent)
        }
        pvcButton = findViewById(R.id.button_pvc)
        pvcButton.setOnClickListener {
            val intent = Intent(this, NameInputActivity::class.java)
            intent.putExtra("numPlayers", 1)
            startActivity(intent)
        }
        exitButton = findViewById(R.id.button_exit)
        exitButton.setOnClickListener {
            finishAffinity()
        }
    }
}